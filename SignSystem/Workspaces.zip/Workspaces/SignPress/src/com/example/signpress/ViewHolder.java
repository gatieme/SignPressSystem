package com.example.signpress;

import android.widget.TextView;

public final class ViewHolder {
	public TextView title;
    public TextView Num;
    public TextView Submit;
}
