package signdata;

public class SignatureTemplate 
{
	public String   SignInfo;
	public Employee SignEmployee;
	public int SignLevel;
    public int CanView;
    public int CanDownload;
}
