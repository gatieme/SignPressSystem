package signsocket;

public class Const
{
	
   public final static String SOCKET_SERVER = "10.0.51.141";

	public final static int SOCKET_PORT = 6666;
	
	// 榛樿timeout 鏃堕棿 60s
	public final static int SOCKET_TIMOUT = 60 * 1000;
	
	public final static int SOCKET_READ_TIMOUT = 15 * 1000;
	
	//濡傛灉娌℃湁杩炴帴鏃犳湇鍔″櫒銆傝绾跨▼鐨剆leep鏃堕棿
	public final static int SOCKET_SLEEP_SECOND = 3 ;
	
	//蹇冭烦鍖呭彂閫侀棿闅旀椂闂�
	public final static int SOCKET_HEART_SECOND =3 ;
	
	public final static String BC = "BC";
	
	
}
