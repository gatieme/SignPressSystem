/** Automatically generated file. DO NOT MODIFY */
package com.hljhw.signature;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}