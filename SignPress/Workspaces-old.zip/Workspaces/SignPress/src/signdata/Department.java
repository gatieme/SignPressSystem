package signdata;

public class Department 
{
	public int Id;
	public String Name;
}
