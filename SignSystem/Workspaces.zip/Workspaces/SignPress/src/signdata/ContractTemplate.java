package signdata;


import java.util.List;
public class ContractTemplate
{
    public String CreateDate;
    
    public  int TempId;
    
    public String Name;
    

    public int ColumnCount = 6;

    public List<String> ColumnNames;     //  �洢5����Ŀ�����Ϣ
        
    public int SignCount = 12;

    public List<SignatureTemplate> SignDatas;

}
