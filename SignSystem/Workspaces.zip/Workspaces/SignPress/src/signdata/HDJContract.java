package signdata;

import java.util.List;

public class HDJContract
{

    public String Name;
    public String SubmitDate;
    public ContractTemplate ConTemp;
    public String Id;   
    public List<String> ColumnDatas;
    public List<String> SignRemarks;
    public Employee SubmitEmployee;
    public List<Integer> SignResults;
}
