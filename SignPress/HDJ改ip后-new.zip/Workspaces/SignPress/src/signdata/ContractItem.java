package signdata;

public class ContractItem {
	public int Id;
	public int ProjectId;
	public String Item;
}
