package signdata;

public class SignatureDetail
{

    public String Date;
    public int EmpId;
    public String ConId;
    public int Result;
    public String Remark;
}
