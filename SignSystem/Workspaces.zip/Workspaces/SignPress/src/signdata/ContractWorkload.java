package signdata;

public class ContractWorkload {

	public String Id;
	public String ContractId;
	public ContractItem Item;
	public double Work;
	public double Expense;
}
