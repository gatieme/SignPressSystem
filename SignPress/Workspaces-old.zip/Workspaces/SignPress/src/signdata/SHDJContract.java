package signdata;

public class SHDJContract {
    public String Id;

    public String Name;
    public String ProjectName;
    public String SubmitDate;
    public String SubmitEmployeeName;
    public int CurrLevel;
    public int MaxLevel;
    public String SignDate;
    public String SignRemark;
    public String SignResult;
}
