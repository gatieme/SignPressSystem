package signdata;

import java.util.List;

public class SignatureStatus
{

    public String Id;
    public String ConId;
    public List<String> Results;
    public int AgreeCount;
    public int RefuseCount;

    public int CurrLevel;

    public int MaxLevel;
}
